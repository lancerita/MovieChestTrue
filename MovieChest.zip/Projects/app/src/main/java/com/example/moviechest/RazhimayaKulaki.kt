package com.example.moviechest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RazhimayaKulaki : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_razzhimaya_kulaki)
    }
}