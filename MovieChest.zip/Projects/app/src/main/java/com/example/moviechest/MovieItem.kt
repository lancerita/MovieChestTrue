package com.example.moviechest

data class MovieItem(val title: String, val imageId: Int, val button: String)
