package com.example.moviechest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class LaCasaDelPapel : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_la_casa_del_papel)
    }
}