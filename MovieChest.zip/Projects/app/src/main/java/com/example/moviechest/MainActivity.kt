package com.example.moviechest

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.moviechest.R.layout.item_movie


class MainActivity : AppCompatActivity() {

    private val recyclerView = findViewById<RecyclerView>(R.id.recycler)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initRecycler()
//      initClickListeners()


    }

    private fun initRecycler() {
        val adapter = MovieAdapter()
        val layoutManager = LinearLayoutManager(this)
          recyclerView.layoutManager = layoutManager
           recyclerView.adapter = adapter

        }

    }



