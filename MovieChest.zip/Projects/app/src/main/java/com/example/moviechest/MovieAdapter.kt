package com.example.moviechest

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

val movies = mutableListOf(
    MovieItem(
        R.string.la_casa_del_papel.toString(),
        R.drawable.la_casa_del_papel,
        R.string.buttonItem.toString()
    ),
    MovieItem(
        R.string.razzhimaya_kulaki.toString(),
        R.drawable.razhimaya_kulaki,
        R.string.buttonItem.toString()
    ),
    MovieItem(
        R.string.years_and_years.toString(),
        R.drawable.years_and_years,
        R.string.buttonItem.toString()
    )
)

class MovieAdapter: RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return MovieViewHolder(inflater.inflate(R.layout.item_movie, parent, false))
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        when (holder) {
            is MovieViewHolder -> {
                holder.bind(movies[position])
            }
        }
    }

    override fun getItemCount(): Int = movies.size


    class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.textViewItem)
        val image: ImageView = itemView.findViewById(R.id.imageViewItem)
        val button: TextView = itemView.findViewById(R.id.buttonItem)

        fun bind(item: MovieItem) {
            title.text = item.title
            button.text = item.button
            image.setImageResource(item.imageId)

            /*public interface MoviesClickListener {
        fun onMoviesClick (movieItem: MovieItem, position: Int)
        fun onFavoriteClick (movieItem: MovieItem, position: Int)
    }*/


        }
    }
}