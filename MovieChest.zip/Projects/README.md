# MovieChestTrue
It is movie search app - my first Android app. There are 7 homeworks in the course, so it will be 7 updates of app. I hope so.
